package ro.raiffeisen.ocl.transactions.test.fake;

import com.datastax.oss.driver.api.core.cql.ExecutionInfo;
import com.datastax.oss.driver.api.core.cql.QueryTrace;
import com.datastax.oss.driver.api.core.cql.Statement;
import com.datastax.oss.driver.api.core.metadata.Node;
import com.datastax.oss.protocol.internal.util.Bytes;
import edu.umd.cs.findbugs.annotations.NonNull;
import edu.umd.cs.findbugs.annotations.Nullable;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletionStage;

public class ExecutionInfoFake implements ExecutionInfo {

    private ByteBuffer pagingState;

    public ExecutionInfoFake(String pagingState) {
        this.pagingState = Bytes.fromHexString(pagingState);
    }

    @NonNull
    @Override
    public Statement<?> getStatement() {
        return null;
    }

    @Nullable
    @Override
    public Node getCoordinator() {
        return null;
    }

    @Override
    public int getSpeculativeExecutionCount() {
        return 0;
    }

    @Override
    public int getSuccessfulExecutionIndex() {
        return 0;
    }

    @NonNull
    @Override
    public List<Map.Entry<Node, Throwable>> getErrors() {
        return null;
    }

    @Nullable
    @Override
    public ByteBuffer getPagingState() {
        return pagingState;
    }

    @NonNull
    @Override
    public List<String> getWarnings() {
        return null;
    }

    @NonNull
    @Override
    public Map<String, ByteBuffer> getIncomingPayload() {
        return null;
    }

    @Override
    public boolean isSchemaInAgreement() {
        return false;
    }

    @Nullable
    @Override
    public UUID getTracingId() {
        return null;
    }

    @NonNull
    @Override
    public CompletionStage<QueryTrace> getQueryTraceAsync() {
        return null;
    }

    @Override
    public int getResponseSizeInBytes() {
        return 0;
    }

    @Override
    public int getCompressedResponseSizeInBytes() {
        return 0;
    }
}
