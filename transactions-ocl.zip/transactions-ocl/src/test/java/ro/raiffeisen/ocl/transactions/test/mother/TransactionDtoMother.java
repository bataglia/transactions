package ro.raiffeisen.ocl.transactions.test.mother;

import com.google.common.collect.ImmutableList;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionDto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionDtoMother {

    public static TransactionDto ibkIntrabankCreditTransaction() {

        final TransactionDto dto = new TransactionDto();
        dto.setKey("17540977|1|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb");
        dto.setInternalId("0d830620-3cc3-11e8-acfc-69b73285ccb");
        dto.setDescription(ImmutableList.of("Plata catre cont Raiffeisen"));
        dto.setChannel("IBK");
        dto.setTransactionType("CR");
        dto.setCounterparty(TransactionCounterpartyMother.raiffeisenClientCounterparty());
        dto.setAmount(BigDecimal.TEN);
        dto.setCreatedAt(LocalDateTime.of(2020, 1, 28, 2, 0, 0, 1000000));
        dto.setTellerCode("IBKC");
        dto.setOrderNumber("1");
        dto.setReference("IB0018012627228100");
        dto.setRecordNumber(1);
        return dto;
    }

}
