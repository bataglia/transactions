package ro.raiffeisen.ocl.transactions.test.mother;

import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionCounterparty;

public class TransactionCounterpartyMother {

    public static TransactionCounterparty raiffeisenClientCounterparty() {

        return new TransactionCounterparty("0004210237", "ALINA IONELA URSAC", "RO34RZBR0000060010798403",
                "RAIFFEISEN BANK S.A.", "RZBRROB0");
    }

}
