package ro.raiffeisen.ocl.transactions.test.fake;

import com.datastax.oss.driver.api.core.PagingIterable;
import com.datastax.oss.driver.api.core.cql.ColumnDefinitions;
import com.datastax.oss.driver.api.core.cql.ExecutionInfo;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class PagingIterableFake<T> implements PagingIterable<T> {

    private List<ExecutionInfo> executionInfos;
    private List<T> rows;

    public PagingIterableFake(final List<T> rows, final String pagingState) {

        this.rows = rows;
        this.executionInfos = Collections.singletonList(new ExecutionInfoFake(pagingState));
    }

    @Override
    public ColumnDefinitions getColumnDefinitions() {
        return null;
    }

    @Override
    public List<ExecutionInfo> getExecutionInfos() {
        return executionInfos;
    }

    @Override
    public boolean isFullyFetched() {
        return false;
    }

    @Override
    public int getAvailableWithoutFetching() {
        return rows.size();
    }

    @Override
    public boolean wasApplied() {
        return false;
    }

    @Override
    public Iterator<T> iterator() {
        return rows.iterator();
    }
}
