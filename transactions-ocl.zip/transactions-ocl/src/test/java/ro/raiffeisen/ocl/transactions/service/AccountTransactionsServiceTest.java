package ro.raiffeisen.ocl.transactions.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransactionKey;
import ro.raiffeisen.ocl.transactions.domain.repository.AccountTransactionsRepository;
import ro.raiffeisen.ocl.transactions.exception.TransactionNotFoundException;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryCriteria;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;
import ro.raiffeisen.ocl.transactions.model.spec.rq.TransactionsSearchRq;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionDto;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionsSearchRs;
import ro.raiffeisen.ocl.transactions.test.mother.*;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AccountTransactionsServiceTest {

    private static final LocalDate FIRST_ACCOUNT_TRANSACTION_DATE = LocalDate.of(2019, 1, 1);

    private AccountTransactionsService accountTransactionsService;

    @Mock
    private AccountTransactionsRepository accountTransactionsRepository;

    @Before
    public void before() {

        accountTransactionsService = new AccountTransactionsService(accountTransactionsRepository, FIRST_ACCOUNT_TRANSACTION_DATE);
    }

    @Test
    public void findByKey() {

        when(accountTransactionsRepository.findByKey(eq(new AccountTransactionKey(
                17540977, 1, Instant.parse("2020-01-28T00:00:00.001Z"), "0d830620-3cc3-11e8-acfc-69b73285ccb"))))
                .thenReturn(Optional.of(AccountTransactionMother.ibkIntrabankCreditTransaction()));

        final TransactionDto byKey = accountTransactionsService.findByKey("17540977|1|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb");

        assertThat(byKey).usingRecursiveComparison().isEqualTo(TransactionDtoMother.ibkIntrabankCreditTransaction());
    }

    @Test(expected = TransactionNotFoundException.class)
    public void findByKeyNotFound() {

        when(accountTransactionsRepository.findByKey(eq(new AccountTransactionKey(
                17540977, 1, Instant.parse("2020-01-28T00:00:00.001Z"), "0d830620-3cc3-11e8-acfc-69b73285ccb"))))
                .thenReturn(Optional.empty());

        accountTransactionsService.findByKey("17540977|1|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb");
    }

    @Test
    public void find() {

        final TransactionsSearchRq rq = TransactionsSearchRqMother.withOneMonthSearchInterval().build();

        when(accountTransactionsRepository.findByCriteria(eq(new AccountTransactionsQueryCriteria(
                rq.getShortAccountNr(), rq.getFrom(), rq.getTo(), new Cursor(2020, 2), 50))))
                .thenReturn(AccountTransactionsQueryResultMother.oneRecord());

        final TransactionsSearchRs actual = accountTransactionsService.find(rq);

        assertThat(actual).isEqualTo(new TransactionsSearchRs(
                null, Collections.singletonList(TransactionDtoMother.ibkIntrabankCreditTransaction())));
    }

    @Test
    public void findNoRecordsFound() {

        final TransactionsSearchRq rq = TransactionsSearchRqMother.withAccount().build();

        when(accountTransactionsRepository.findByCriteria(any()))
                .thenReturn(AccountTransactionsQueryResultMother.empty());

        final TransactionsSearchRs actual = accountTransactionsService.find(rq);

        assertThat(actual).isEqualTo(TransactionsSearchRsMother.empty());
    }

    @Test
    public void findOverTwoMonthPartitions() {

        final TransactionsSearchRq rq = TransactionsSearchRqMother.withOneMonthSearchInterval()
                .to(LocalDate.of(2020, 1, 1))
                .build();

        stubFindByCriteria(rq, 2020, 2, 1);

        accountTransactionsService.find(rq);
    }

    private void stubFindByCriteria(final TransactionsSearchRq rq,
                                    final int year,
                                    final int... months) {

        for (int month : months) {
            when(accountTransactionsRepository.findByCriteria(eq(new AccountTransactionsQueryCriteria(
                    rq.getShortAccountNr(), rq.getFrom(), rq.getTo(), new Cursor(year, month), 50))))
                    .thenReturn(AccountTransactionsQueryResultMother.empty());

        }
    }

    @Test
    public void findOverYearTransition() {

        final TransactionsSearchRq rq = TransactionsSearchRqMother.withAccount()
                .from(LocalDate.of(2020, 1, 1))
                .to(LocalDate.of(2019, 12, 1))
                .build();

        stubFindByCriteria(rq, 2020, 1);
        stubFindByCriteria(rq, 2019, 12);

        accountTransactionsService.find(rq);
    }

}