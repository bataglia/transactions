package ro.raiffeisen.ocl.transactions.test.mother;

import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionsSearchRs;

import java.util.Collections;

public class TransactionsSearchRsMother {

    public static TransactionsSearchRs empty() {

        return new TransactionsSearchRs(null, Collections.emptyList());
    }

}
