package ro.raiffeisen.ocl.transactions.test.mother;

import ro.raiffeisen.ocl.transactions.model.spec.rq.TransactionsSearchRq;

import java.time.LocalDate;

public class TransactionsSearchRqMother {

    public static TransactionsSearchRq.TransactionsSearchRqBuilder withAccount() {

        return TransactionsSearchRq.builder()
                .shortAccountNr(12312321);
    }

    public static TransactionsSearchRq.TransactionsSearchRqBuilder withOneMonthSearchInterval() {

        return withAccount()
                .from(LocalDate.of(2020, 2, 29))
                .to(LocalDate.of(2020, 2, 1));
    }

}
