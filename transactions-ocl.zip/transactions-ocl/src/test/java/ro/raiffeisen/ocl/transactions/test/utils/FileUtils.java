package ro.raiffeisen.ocl.transactions.test.utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtils {

    public static String readFileAsString(final String path) {
        try {
            final ClassLoader classLoader = FileUtils.class.getClassLoader();
            final File jsonFile = new File(classLoader.getResource(path).getFile());
            return new String(Files.readAllBytes(Paths.get(jsonFile.getAbsolutePath())));
        } catch (final Exception e) {
            throw new RuntimeException("Error reading file at " + path, e);
        }
    }

}
