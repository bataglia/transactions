package ro.raiffeisen.ocl.transactions.test.mother;

import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryResult;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;

import java.util.Collections;

public class AccountTransactionsQueryResultMother {

    public static AccountTransactionsQueryResult empty() {

        return new AccountTransactionsQueryResult(Collections.emptyList(), null);
    }

    public static AccountTransactionsQueryResult oneRecord() {

        return new AccountTransactionsQueryResult(Collections.singletonList(AccountTransactionMother.ibkIntrabankCreditTransaction()), null);
    }

    public static AccountTransactionsQueryResult oneRecordWithCursor() {

        final AccountTransactionsQueryResult result = oneRecord();
        result.setCursor(new Cursor(2020, 1, "0x002f0008000001612fc38c012434303331363364302d336436352d313165382d616366632d363962373332383563636236f07ffffffef07ffffffe00"));
        return result;
    }

}
