package ro.raiffeisen.ocl.transactions.domain.repository;

import com.datastax.oss.driver.api.core.PagingIterable;
import com.datastax.oss.driver.api.core.cql.ExecutionInfo;
import com.datastax.oss.protocol.internal.util.Bytes;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransactionKey;
import ro.raiffeisen.ocl.transactions.domain.repository.dao.AccountTransactionDao;
import ro.raiffeisen.ocl.transactions.domain.repository.dao.TransactionDaoMapper;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryCriteria;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryResult;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;
import ro.raiffeisen.ocl.transactions.test.fake.PagingIterableFake;
import ro.raiffeisen.ocl.transactions.test.mother.AccountTransactionMother;
import ro.raiffeisen.ocl.transactions.test.mother.AccountTransactionsQueryResultMother;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;
import java.util.function.Function;

import static org.assertj.core.api.Assertions.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AccountTransactionsRepositoryTest {

    @InjectMocks
    private AccountTransactionsRepository repository;

    @Mock
    private TransactionDaoMapper transactionDaoMapper;

    @Mock
    private AccountTransactionDao accountTransactionDao;

    @Test
    public void findByKey() {

        final AccountTransactionKey key = new AccountTransactionKey(
                123125412, 1, Instant.parse("2020-01-01T12:00:00.001Z"), "0d830620-3cc3-11e8-acfc-69b73285ccb");
        when(transactionDaoMapper.accountTransactionDao(eq("transactions_2020"))).thenReturn(accountTransactionDao);
        when(accountTransactionDao.findByPk(eq(key.getAccountNr()), eq(key.getPostingMonth()), eq(key.getIcbsInsertTimestamp()), eq(key.getId())))
                .thenReturn(Optional.empty());

        final Optional<AccountTransaction> actual = repository.findByKey(key);

        assertThat(actual).isEmpty();
    }

    @Test
    public void findByCriteria() {

        final AccountTransactionsQueryCriteria criteria = new AccountTransactionsQueryCriteria(
                123125412, LocalDate.parse("2020-01-01"), LocalDate.parse("2020-01-31"),
                new Cursor(2020, 1, null), 1);

        when(transactionDaoMapper.accountTransactionDao(eq("transactions_2020"))).thenReturn(accountTransactionDao);
        when(accountTransactionDao.findByAccountNoAndMonth(eq(criteria.getShortAccountNr()), eq(criteria.getCursor().getPartitionMonth()), any(Function.class)))
                .thenReturn(new PagingIterableFake<>(Collections.singletonList(AccountTransactionMother.ibkIntrabankCreditTransaction()), "0x002f0008000001612fc38c012434303331363364302d336436352d313165382d616366632d363962373332383563636236f07ffffffef07ffffffe00"));

        final AccountTransactionsQueryResult actual = repository.findByCriteria(criteria);

        assertThat(actual).usingRecursiveComparison().isEqualTo(AccountTransactionsQueryResultMother.oneRecordWithCursor());

    }

}