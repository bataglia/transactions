package ro.raiffeisen.ocl.transactions.test.mother;

import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;

import java.math.BigDecimal;
import java.time.Instant;

public class AccountTransactionMother {

    public static AccountTransaction ibkIntrabankCreditTransaction() {

        final AccountTransaction transaction = new AccountTransaction();
        transaction.setId("0d830620-3cc3-11e8-acfc-69b73285ccb");
        transaction.setTxnDesc1("Plata catre cont Raiffeisen");
        transaction.setChannel("IBK");
        transaction.setDbCr("CR");
        transaction.setAccountNr(17540977);
        transaction.setPostingMonth(1);
        transaction.setCounterpartyCif("0004210237");
        transaction.setCounterpartyName("ALINA IONELA URSAC");
        transaction.setCounterpartyIban("RO34RZBR0000060010798403");
        transaction.setCounterpartyBankName("RAIFFEISEN BANK S.A.");
        transaction.setCounterpartyBankBic("RZBRROB0");
        transaction.setAmount(BigDecimal.TEN);
        transaction.setIcbsInsertTimestamp(Instant.parse("2020-01-28T00:00:00.001Z"));
        transaction.setTellerCode("IBKC");
        transaction.setOrderNumber("1");
        transaction.setReference("IB0018012627228100");
        transaction.setCounter(1);
        return transaction;
    }

}
