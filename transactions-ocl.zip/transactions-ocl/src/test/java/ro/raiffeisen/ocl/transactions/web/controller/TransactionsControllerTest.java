package ro.raiffeisen.ocl.transactions.web.controller;

import org.junit.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import ro.raiffeisen.ocl.transactions.exception.TransactionNotFoundException;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionsSearchRs;
import ro.raiffeisen.ocl.transactions.service.AccountTransactionsService;
import ro.raiffeisen.ocl.transactions.test.mother.TransactionDtoMother;

import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static ro.raiffeisen.ocl.transactions.test.utils.FileUtils.readFileAsString;

@WebMvcTest(TransactionsController.class)
public class TransactionsControllerTest extends AbstractComponentTest {

    @MockBean
    private AccountTransactionsService accountTransactionsService;

    @Test
    public void getTransactionByKey() throws Exception {

        when(accountTransactionsService.findByKey(eq("17540977|2|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb")))
                .thenReturn(TransactionDtoMother.ibkIntrabankCreditTransaction());

        mockMvc.perform(
                get("/v1/transactions/17540977|2|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(readFileAsString("json/response/getTransactionByKeyExpected.json")));
    }

    @Test
    public void getTransactionByKeyWhenNotFound() throws Exception {

        when(accountTransactionsService.findByKey(eq("17540977|2|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb")))
                .thenThrow(new TransactionNotFoundException("No transaction found!"));

        mockMvc.perform(
                get("/v1/transactions/17540977|2|2020-01-28T00:00:00.001Z|0d830620-3cc3-11e8-acfc-69b73285ccb"))
                .andDo(print())
                .andExpect(status().isNotFound());
    }

    @Test
    public void getTransactions() throws Exception {

        when(accountTransactionsService.find(any()))
                .thenReturn(new TransactionsSearchRs(new Cursor(2020, 1, "0x002f0008000001612fc38c012434303331363364302d336436352d313165382d616366632d363962373332383563636236f07ffffffef07ffffffe00"),
                        Collections.singletonList(TransactionDtoMother.ibkIntrabankCreditTransaction())));

        mockMvc.perform(
                get("/v1/transactions?from=2020-02-12&to=2019-01-01&maxRows=1&shortAccountNr=7591289"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(readFileAsString("json/response/getTransactionsExpected.json")));
    }

    @Test
    public void getTransactionsNoDataFound() throws Exception {

        when(accountTransactionsService.find(any()))
                .thenReturn(new TransactionsSearchRs(null, Collections.emptyList()));

        mockMvc.perform(
                get("/v1/transactions?from=2020-02-12&to=2019-01-01&maxRows=1&shortAccountNr=7591289&cursor=2019::11::0x002f0008000001670537c4032431633966613965322d653666322d313165382d396265382d393135356563316233353531f07ffffffdf07ffffffd00"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(readFileAsString("json/response/getTransactionsNoDataFoundExpected.json")));
    }

}