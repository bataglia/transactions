package ro.raiffeisen.ocl.transactions.helper.factory;

import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransactionKey;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;

import java.time.Instant;

public class AccountTransactionKeyFactory {

    private static final String KEY_FIELD_SEPARATOR = "|";
    private static final String KEY_SPLIT_REGEX = "\\" + KEY_FIELD_SEPARATOR;

    public static String serializeKey(AccountTransaction entity) {

        return entity.getAccountNr() + KEY_FIELD_SEPARATOR + entity.getPostingMonth() + "|"
                + entity.getIcbsInsertTimestamp() + "|" + entity.getId();
    }

    public static AccountTransactionKey deserializeKey(String key) {

        final String[] split = key.split(KEY_SPLIT_REGEX);

        return new AccountTransactionKey(Long.parseLong(split[0]), Integer.parseInt(split[1]), Instant.parse(split[2]), split[3]);
    }

}
