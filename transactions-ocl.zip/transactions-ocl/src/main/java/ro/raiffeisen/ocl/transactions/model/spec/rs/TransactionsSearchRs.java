package ro.raiffeisen.ocl.transactions.model.spec.rs;

import lombok.AllArgsConstructor;
import lombok.Data;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;

import java.util.List;

@AllArgsConstructor
@Data
public class TransactionsSearchRs {

    private Cursor cursor;

    private List<TransactionDto> transactions;

}
