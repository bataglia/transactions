package ro.raiffeisen.ocl.transactions.helper.logging;

import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import ro.raiffeisen.ocl.transactions.helper.constants.HttpHeaders;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
public class HttpLoggingRequestInterceptorAdapter extends HandlerInterceptorAdapter {

    private static final ThreadLocal<LoggingContext> LOGGING_CTX_TL = new ThreadLocal<>();

    @Override
    public boolean preHandle(final HttpServletRequest request,
                             final HttpServletResponse response,
                             final Object handler) {

        final LoggingContext lc = new LoggingContext();
        lc.startTime = System.currentTimeMillis();

        lc.commonMarkers = Markers.append(MarkerFields.HTTP_REQ_URL, request.getRequestURI())
                .and(Markers.append(MarkerFields.HTTP_METHOD, request.getMethod()))
                .and(Markers.append(MarkerFields.HTTP_QUERY_PARAMS, request.getQueryString()))
                .and(Markers.append(MarkerFields.USERNAME, request.getHeader(HttpHeaders.USERNAME)))
                .and(Markers.append(MarkerFields.CHANNEL, request.getHeader(HttpHeaders.APP_NAME)));

        LOGGING_CTX_TL.set(lc);

        LOGGER.info(lc.commonMarkers, "Request processing started...");
        return true;
    }

    @Override
    public void afterCompletion(final HttpServletRequest request,
                                final HttpServletResponse response,
                                final Object handler,
                                final Exception ex) {

        try {
            final LoggingContext loggingContext = LOGGING_CTX_TL.get();

            loggingContext.commonMarkers
                    .and(Markers.append(MarkerFields.HTTP_STATUS_CODE, response.getStatus()))
                    .and(Markers.append(MarkerFields.EXECUTION_TIME, System.currentTimeMillis() - loggingContext.startTime));
            if (ex != null) {
                loggingContext.commonMarkers
                        .and(Markers.append(MarkerFields.EXECUTION_EXCEPTION, ex.getClass()))
                        .and(Markers.append(MarkerFields.EXECUTION_EXCEPTION_MSG, ex.getMessage()));
            }
            LOGGER.info(loggingContext.commonMarkers, "Request processing ended.");
        } finally {
            LOGGING_CTX_TL.remove();
        }
    }

    private static class LoggingContext {
        LogstashMarker commonMarkers;
        Long startTime;
    }

    private static final class MarkerFields {

        private static final String CHANNEL = "channel";
        private static final String USERNAME = "channel";
        private static final String EXECUTION_TIME = "execution_time";
        private static final String EXECUTION_EXCEPTION = "exception";
        private static final String EXECUTION_EXCEPTION_MSG = "exception_message";
        private static final String HTTP_REQ_URL = "req_url";
        private static final String HTTP_METHOD = "http_method";
        private static final String HTTP_STATUS_CODE = "http_status";
        private static final String HTTP_QUERY_PARAMS = "http_query_params";

    }

}
