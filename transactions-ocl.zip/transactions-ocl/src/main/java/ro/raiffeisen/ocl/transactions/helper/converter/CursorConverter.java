package ro.raiffeisen.ocl.transactions.helper.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;

@Component
public class CursorConverter implements Converter<String, Cursor> {

    @Override
    public Cursor convert(final String serializedCursor) {

        final String[] split = serializedCursor.split(Cursor.CURSOR_FIELDS_SEPARATOR);

        return new Cursor(Integer.parseInt(split[0]), Integer.parseInt(split[1]), split[2]);
    }
}
