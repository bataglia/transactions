package ro.raiffeisen.ocl.transactions.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;

import java.util.List;

@Data
@AllArgsConstructor
public class AccountTransactionsQueryResult {

    private List<AccountTransaction> transactions;

    private Cursor cursor;

}
