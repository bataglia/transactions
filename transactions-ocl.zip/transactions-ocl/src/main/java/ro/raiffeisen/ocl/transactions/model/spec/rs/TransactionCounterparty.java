package ro.raiffeisen.ocl.transactions.model.spec.rs;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class TransactionCounterparty {

    private String cif;
    private String name;
    private String iban;
    private String bankName;
    private String bankBic;

}
