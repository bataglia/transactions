package ro.raiffeisen.ocl.transactions.helper.constants;

public class HttpHeaders {

    public static final String USERNAME = "X-RBRO-ApplicationUsername";
    public static final String APP_NAME = "X-RBRO-ApplicationName";

}
