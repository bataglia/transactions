package ro.raiffeisen.ocl.transactions.domain.repository;

import com.datastax.oss.driver.api.core.PagingIterable;
import com.datastax.oss.driver.api.core.cql.BoundStatementBuilder;
import com.datastax.oss.protocol.internal.util.Bytes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryCriteria;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryResult;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransactionKey;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;
import ro.raiffeisen.ocl.transactions.domain.repository.dao.AccountTransactionDao;
import ro.raiffeisen.ocl.transactions.domain.repository.dao.TransactionDaoMapper;
import ro.raiffeisen.ocl.transactions.helper.utils.DateUtils;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

@Slf4j
@Repository
@RequiredArgsConstructor
public class AccountTransactionsRepository {

    //TODO
    public static final String TRANSACTIONS_TABLE_PREFIX = "transactions_";
//    public static final String TRANSACTIONS_TABLE_PREFIX = "account_transactions_";

    private final TransactionDaoMapper transactionDaoMapper;

    public Optional<AccountTransaction> findByKey(final AccountTransactionKey key) {

        LOGGER.debug("Fetching transaction with key = {}", key);
        return getAccountTransactionDaoByTableYear(DateUtils.fromInstant(key.getIcbsInsertTimestamp()).getYear())
                .findByPk(key.getAccountNr(), key.getPostingMonth(), key.getIcbsInsertTimestamp(), key.getId());
    }

    public AccountTransactionsQueryResult findByCriteria(final AccountTransactionsQueryCriteria criteria) {

        LOGGER.debug("Fetching rows for criteria = {}", criteria);
        final AccountTransactionDao dao = getAccountTransactionDaoByTableYear(criteria.getCursor().getTableYear());
        final PagingIterable<AccountTransaction> byAccountNoAndMonth = findByCriteria(dao, criteria);
        final Cursor cursor = extractCursor(byAccountNoAndMonth, criteria.getCursor());
        final List<AccountTransaction> accountTransactions = extractAvailableRows(byAccountNoAndMonth);
        LOGGER.debug("Rows fetching completed!");
        return new AccountTransactionsQueryResult(accountTransactions, cursor);
    }

    private PagingIterable<AccountTransaction> findByCriteria(final AccountTransactionDao dao,
                                                              final AccountTransactionsQueryCriteria criteria) {

        final String solrQuery = AccountTransactionsSolrQueryFactory.from(criteria);
        if (solrQuery == null) {
            return dao.findByAccountNoAndMonth(
                    criteria.getShortAccountNr(),
                    criteria.getCursor().getPartitionMonth(),
                    getStatementBuilderMetaPropsSetterFunction(criteria));
        } else {
            LOGGER.trace("Using SOLR query {}", solrQuery);
            return dao.findByAccountNoAndMonthAndSolrQuery(
                    criteria.getShortAccountNr(),
                    criteria.getCursor().getPartitionMonth(),
                    solrQuery,
                    getStatementBuilderMetaPropsSetterFunction(criteria));
        }
    }

    private AccountTransactionDao getAccountTransactionDaoByTableYear(final int year) {
        return transactionDaoMapper.accountTransactionDao(TRANSACTIONS_TABLE_PREFIX + year);
    }

    private Function<BoundStatementBuilder, BoundStatementBuilder> getStatementBuilderMetaPropsSetterFunction(
            final AccountTransactionsQueryCriteria criteria) {

        return boundStatementBuilder -> boundStatementBuilder
                .setPageSize(criteria.getMaxRows())
                .setPagingState(criteria.getCursor().getDbCursor() == null ?
                        null : Bytes.fromHexString(criteria.getCursor().getDbCursor()));
    }

    private Cursor extractCursor(final PagingIterable<AccountTransaction> rs, final Cursor existingCursor) {

        final ByteBuffer pagingState = rs.getExecutionInfo().getPagingState();
        if (pagingState == null) {
            return null;
        } else {
            return new Cursor(existingCursor.getTableYear(), existingCursor.getPartitionMonth(), Bytes.toHexString(pagingState));
        }
    }

    private List<AccountTransaction> extractAvailableRows(final PagingIterable<AccountTransaction> byAccountNoAndMonth) {

        int pageRows = byAccountNoAndMonth.getAvailableWithoutFetching();
        LOGGER.debug("{} rows available without fetching.", pageRows);
        final List<AccountTransaction> accountTransactions = new ArrayList<>(pageRows);
        if (pageRows > 0) {
            for (final AccountTransaction accountTransaction : byAccountNoAndMonth) {
                accountTransactions.add(accountTransaction);
                // Make sure we don't go past the current page (we don't want the driver to fetch the next one)
                if (--pageRows == 0) {
                    break;
                }
            }
        }
        return accountTransactions;
    }

}

