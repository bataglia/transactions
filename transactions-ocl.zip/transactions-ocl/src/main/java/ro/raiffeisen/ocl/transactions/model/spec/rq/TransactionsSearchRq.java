package ro.raiffeisen.ocl.transactions.model.spec.rq;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.AssertFalse;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionsSearchRq {

    private long shortAccountNr;

    private String transactionType;

    private BigDecimal minAmount;

    private BigDecimal maxAmount;

    private String query;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate from;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate to;

    private Cursor cursor;

    @Positive(message = "maxRows must be greater than 0")
    private Integer maxRows;

    @AssertFalse(message = "to cannot be higher than from")
    public boolean isSearchIntervalValid() {
        return (from == null || to == null) || (from.compareTo(to) < 0);
    }

}
