package ro.raiffeisen.ocl.transactions.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@AllArgsConstructor
@Data
public class AccountTransactionKey {

    private long accountNr;

    private int postingMonth;

    private Instant icbsInsertTimestamp;

    private String id;

}
