package ro.raiffeisen.ocl.transactions.web.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import ro.raiffeisen.ocl.transactions.service.AccountTransactionsService;
import ro.raiffeisen.ocl.transactions.model.spec.rq.TransactionsSearchRq;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionDto;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionsSearchRs;

import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
public class TransactionsController {

    private final AccountTransactionsService accountTransactionsService;

    @GetMapping("/v1/transactions/{transactionKey}")
    public TransactionDto getTransactionByKey(@PathVariable final String transactionKey) {
        return accountTransactionsService.findByKey(transactionKey);
    }

    @GetMapping("/v1/transactions")
    public TransactionsSearchRs getTransactions(@Valid final TransactionsSearchRq transactionsSearchRq) {
        return accountTransactionsService.find(transactionsSearchRq);
    }

}
