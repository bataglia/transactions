package ro.raiffeisen.ocl.transactions.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ro.raiffeisen.ocl.transactions.domain.repository.CassandraKeyspaceRepository;
import ro.raiffeisen.ocl.transactions.domain.repository.AccountTransactionsRepository;
import ro.raiffeisen.ocl.transactions.helper.utils.DateUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Configuration
public class TransactionsConfiguration {

    @Bean
    public LocalDate firstAccountTransactionDate(final CassandraKeyspaceRepository cassandraKeyspaceRepository) {

        final List<String> keyspaceTables = cassandraKeyspaceRepository.getTables();

        final Integer lastTableYear = getFirstTransactionsTableYear(keyspaceTables)
                .orElse(DateUtils.currentDate().getYear());

        return LocalDate.of(lastTableYear, 1, 1);
    }

    private Optional<Integer> getFirstTransactionsTableYear(final List<String> keyspaceTables) {
        return keyspaceTables.stream()
                .filter(this::isTransactionsTable)
                .map(this::extractTransactionsTableYear)
                .min(Integer::compare);
    }

    private boolean isTransactionsTable(final String tableName) {

        return tableName.matches(AccountTransactionsRepository.TRANSACTIONS_TABLE_PREFIX + "\\d+");
    }

    private int extractTransactionsTableYear(final String tableName) {

        return Integer.parseInt(tableName.split(AccountTransactionsRepository.TRANSACTIONS_TABLE_PREFIX)[1]);
    }

}

