package ro.raiffeisen.ocl.transactions.domain.repository;

import com.datastax.oss.driver.api.core.CqlSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CassandraKeyspaceRepository {

    private final CqlSession cqlSession;

    private final String keyspace;

    public CassandraKeyspaceRepository(final CqlSession cqlSession,
                                       @Value("${datastax-java-driver.basic.session-keyspace}") final String keyspace) {
        this.cqlSession = cqlSession;
        this.keyspace = keyspace;
    }

    public List<String> getTables() {

        return cqlSession.execute(cqlSession.prepare("SELECT table_name FROM system_schema.tables WHERE keyspace_name=?")
                .bind(keyspace))
                .map(row -> row.getString("table_name"))
                .all();
    }

}
