package ro.raiffeisen.ocl.transactions.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class AccountTransactionsQueryCriteria {

    private long shortAccountNr;

    private LocalDate from;

    private LocalDate to;

    private Cursor cursor;

    private int maxRows;

    private BigDecimal minAmount;

    private BigDecimal maxAmount;

    private String query;

}
