package ro.raiffeisen.ocl.transactions.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ro.raiffeisen.ocl.transactions.helper.logging.HttpLoggingRequestInterceptorAdapter;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(final InterceptorRegistry registry) {
        registry.addInterceptor(new HttpLoggingRequestInterceptorAdapter());
    }

}