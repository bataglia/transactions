package ro.raiffeisen.ocl.transactions.model.spec.rq;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.Month;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cursor {

    public static final String CURSOR_FIELDS_SEPARATOR = "::";

    private int tableYear;
    private int partitionMonth;
    private String dbCursor;

    @JsonValue
    public String jsonValue() {
        return tableYear + CURSOR_FIELDS_SEPARATOR + partitionMonth + CURSOR_FIELDS_SEPARATOR + dbCursor;
    }

    public Cursor(final int tableYear, final int partitionMonth) {
        this.tableYear = tableYear;
        this.partitionMonth = partitionMonth;
    }

    public static Cursor of(final LocalDate date) {
        return new Cursor(date.getYear(), date.getMonthValue());
    }

    public Cursor next() {

        int month = this.partitionMonth;
        int tableYear = this.tableYear;
        if (month == Month.JANUARY.getValue()) {
            month = Month.DECEMBER.getValue();
            tableYear--;
        } else {
            month--;
        }
        return new Cursor(tableYear, month);
    }

}
