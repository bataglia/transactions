package ro.raiffeisen.ocl.transactions.helper.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    public static final DateTimeFormatter ICBS_POSTING_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private static final ZoneId ROMANIA_ZONE_ID = ZoneId.of("Europe/Bucharest");

    public static LocalDate currentDate() {
        return currentTime().toLocalDate();
    }

    public static LocalDateTime currentTime() {
        return LocalDateTime.ofInstant(Instant.now(), ROMANIA_ZONE_ID);
    }

    public static LocalDate max(final LocalDate d1, final LocalDate d2) {

        return d1.compareTo(d2) > 0 ? d1 : d2;
    }

    public static LocalDateTime fromInstant(final Instant instant) {

        return LocalDateTime.ofInstant(instant, ROMANIA_ZONE_ID);
    }

}
