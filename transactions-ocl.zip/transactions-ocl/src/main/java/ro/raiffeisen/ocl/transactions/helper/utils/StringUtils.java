package ro.raiffeisen.ocl.transactions.helper.utils;

import java.util.ArrayList;
import java.util.List;

public class StringUtils {

    public static String trimAndNullifyIfEmpty(final String val) {
        if (val == null) {
            return null;
        } else {
            final String trimmedVal = val.trim();
            return trimmedVal.length() == 0 ? null : trimmedVal;
        }
    }

    public static List<String> asListFilterEmpty(final String... values) {
        final List<String> descriptionList = new ArrayList<>();
        for (final String value : values) {
            final String trimmedValue = StringUtils.trimAndNullifyIfEmpty(value);
            if (trimmedValue != null) {
                descriptionList.add(trimmedValue);
            }
        }
        return descriptionList.isEmpty() ? null : descriptionList;
    }

    public static boolean isNullOrEmptyAfterTrimming(final String val) {

        return val != null && !org.apache.commons.lang3.StringUtils.isEmpty(val.trim());
    }

}