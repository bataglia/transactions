package ro.raiffeisen.ocl.transactions.model.spec.rs;

import lombok.Data;
import ro.raiffeisen.ocl.transactions.helper.factory.AccountTransactionKeyFactory;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;
import ro.raiffeisen.ocl.transactions.helper.utils.DateUtils;
import ro.raiffeisen.ocl.transactions.helper.utils.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

@Data
public class TransactionDto {

    private String key;
    private String internalId;
    private List<String> description;
    private String channel;
    private String transactionType; //DEBIT / CREDIT
    private TransactionCounterparty counterparty;
    private BigDecimal amount;
    private LocalDateTime createdAt;
    private LocalDate postedAt;
    private String tellerCode;
    private String orderNumber;
    private BigDecimal originalAmount;
    private String originalCurrency;
    private BigDecimal originalExchangeRate;
    private String reference;
    private String reversePaymentRejectMessage;
    private String tppName;
    private String tppApplicationName;
    private int recordNumber;

    public static TransactionDto from(final AccountTransaction entity) {

        final TransactionDto dto = new TransactionDto();
        dto.setKey(AccountTransactionKeyFactory.serializeKey(entity));
        dto.setInternalId(entity.getId());
        dto.setAmount(entity.getAmount());
        dto.setChannel(entity.getChannel());
        dto.setTransactionType(entity.getDbCr());
        dto.setDescription(StringUtils.asListFilterEmpty(
                entity.getTxnDesc1(), entity.getTxnDesc2(), entity.getTxnDesc3(),
                entity.getTxnDesc4(), entity.getTxnDesc5(), entity.getTxnDesc6(),
                entity.getTxnDesc7(), entity.getTxnDesc8(), entity.getTxnDesc9()));
        dto.setCounterparty(new TransactionCounterparty(
                entity.getCounterpartyCif(), entity.getCounterpartyName(), entity.getCounterpartyIban(),
                entity.getCounterpartyBankName(), entity.getCounterpartyBankBic()));
        dto.setCreatedAt(DateUtils.fromInstant(entity.getIcbsInsertTimestamp()));
        if (entity.getIcbsPostingDate() != null) { //TODO remove after datafix
            dto.setPostedAt(
                    LocalDate.from(DateUtils.ICBS_POSTING_DATE_FORMAT.parse(entity.getIcbsPostingDate().toString())));
        }
        dto.setOrderNumber(entity.getOrderNumber());

        final BigDecimal originalExchangeRate = entity.getOriginalExchangeRate();
        final BigDecimal exchangeRate = entity.getExchangeRate();
        if (StringUtils.isNullOrEmptyAfterTrimming(entity.getOriginalCurrency())) {
            dto.setOriginalCurrency(entity.getOriginalCurrency());
            dto.setOriginalAmount(entity.getOriginalAmount());
            dto.setOriginalExchangeRate(originalExchangeRate);
        }

        final boolean isOriginalExchangeRateNotAvailable =
                isNull(originalExchangeRate) || BigDecimal.ZERO.equals(originalExchangeRate);
        final boolean isExchangeRateAvailable = nonNull(exchangeRate)
                && !BigDecimal.ZERO.equals(exchangeRate) && !BigDecimal.ONE.equals(exchangeRate);

        if (isOriginalExchangeRateNotAvailable && isExchangeRateAvailable) {
            dto.setOriginalExchangeRate(exchangeRate);
        }
        dto.setRecordNumber(entity.getCounter());
        dto.setTellerCode(entity.getTellerCode());
        dto.setReference(entity.getReference());
        dto.setReversePaymentRejectMessage(entity.getReversePaymentRejectMessage());
        dto.setTppName(entity.getTppName());
        dto.setTppApplicationName(entity.getTppApplicationName());
        return dto;
    }

}
