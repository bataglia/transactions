package ro.raiffeisen.ocl.transactions.service;

import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import ro.raiffeisen.ocl.transactions.exception.TransactionNotFoundException;
import ro.raiffeisen.ocl.transactions.helper.factory.AccountTransactionKeyFactory;
import ro.raiffeisen.ocl.transactions.helper.factory.AccountTransactionsQueryCriteriaFactory;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryCriteria;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryResult;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;
import ro.raiffeisen.ocl.transactions.model.spec.rq.TransactionsSearchRq;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionDto;
import ro.raiffeisen.ocl.transactions.model.spec.rs.TransactionsSearchRs;
import ro.raiffeisen.ocl.transactions.domain.repository.AccountTransactionsRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AccountTransactionsService {

    private final AccountTransactionsRepository accountTransactionsRepository;
    private final LocalDate firstAccountTransactionDate;

    public TransactionDto findByKey(final String key) {

        return accountTransactionsRepository.findByKey(AccountTransactionKeyFactory.deserializeKey(key))
                .map(TransactionDto::from)
                .orElseThrow(() -> new TransactionNotFoundException("No transaction found for given key " + key + "!"));
    }

    public TransactionsSearchRs find(final TransactionsSearchRq request) {

        final AccountTransactionsQueryCriteria queryCriteria = AccountTransactionsQueryCriteriaFactory.of(
                request, firstAccountTransactionDate);
        final int maxRows = queryCriteria.getMaxRows();
        final List<TransactionDto> accountTransactions = new ArrayList<>(maxRows);

        while (true) {
            final AccountTransactionsQueryResult queryResult = accountTransactionsRepository.findByCriteria(queryCriteria);
            if (CollectionUtils.isNotEmpty(queryResult.getTransactions())) {
                accountTransactions.addAll(mapToDto(queryResult.getTransactions()));
            }
            final Cursor nextCursor = queryCriteria.getCursor().next();
            final boolean isRequestedPageSizeIncomplete = accountTransactions.size() < maxRows;
            if (isRequestedPageSizeIncomplete && isCursorInCriteriaRange(nextCursor, queryCriteria.getTo())) {
                queryCriteria.setCursor(nextCursor);
            } else {
                queryCriteria.setCursor(queryResult.getCursor());
                break;
            }
        }
        return new TransactionsSearchRs(queryCriteria.getCursor(), accountTransactions);
    }

    private boolean isCursorInCriteriaRange(final Cursor cursor, final LocalDate criteriaLowerDateLimit) {
        return cursor.getTableYear() >= criteriaLowerDateLimit.getYear() &&
                cursor.getPartitionMonth() >= criteriaLowerDateLimit.getMonthValue();
    }

    private List<TransactionDto> mapToDto(final List<AccountTransaction> accountTransactions) {

        return accountTransactions.stream()
                .map(TransactionDto::from)
                .collect(Collectors.toList());
    }

}
