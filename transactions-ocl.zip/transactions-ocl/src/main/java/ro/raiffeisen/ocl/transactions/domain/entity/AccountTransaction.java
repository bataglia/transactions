package ro.raiffeisen.ocl.transactions.domain.entity;

import com.datastax.oss.driver.api.mapper.annotations.ClusteringColumn;
import com.datastax.oss.driver.api.mapper.annotations.CqlName;
import com.datastax.oss.driver.api.mapper.annotations.Entity;
import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Data
public class AccountTransaction {

    @CqlName("account_no")
    @PartitionKey
    private long accountNr;

    @CqlName("posting_month")
    @PartitionKey(1)
    private int postingMonth;

    @CqlName("txn_timestamp")
    @ClusteringColumn
    private Instant icbsInsertTimestamp;

    @CqlName("txn_unique_id")
    @ClusteringColumn(1)
    private String id;

    @CqlName("txn_write_timestamp")
    private Instant asrInsertTimestamp;

    //20, 26
    @CqlName("account_type")
    private byte accountType;

    @CqlName("account_ccy_iso")
    private String accountCurrency;

    @CqlName("cust_id")
    private String cif;

    //PI / LE
    @CqlName("segmentation_cust_type")
    private String segmentationCustType;

    @CqlName("txn_posting_date")
    private Integer icbsPostingDate;

    @CqlName("txn_effective_date")
    private int icbsEffectiveDate;

    @CqlName("txn_counter")
    private int counter;

    @CqlName("txn_desc_1")
    private String txnDesc1;

    @CqlName("txn_desc_2")
    private String txnDesc2;

    @CqlName("txn_desc_3")
    private String txnDesc3;

    @CqlName("txn_desc_4")
    private String txnDesc4;

    @CqlName("txn_desc_5")
    private String txnDesc5;

    @CqlName("txn_desc_6")
    private String txnDesc6;

    @CqlName("txn_desc_7")
    private String txnDesc7;

    @CqlName("txn_desc_8")
    private String txnDesc8;

    @CqlName("txn_desc_9")
    private String txnDesc9;

    @CqlName("amount")
    private BigDecimal amount;

    @CqlName("amount_local_ccy")
    private BigDecimal ronAmount;

    @CqlName("db_cr")
    private String dbCr;

    @CqlName("client_name")
    private String counterpartyName;

    @CqlName("client_bank_bic")
    private String counterpartyBankBic;

    @CqlName("client_bank_name")
    private String counterpartyBankName;

    @CqlName("client_iban")
    private String counterpartyIban;

    @CqlName("txn_channel")
    private String channel;

    @CqlName("txn_direct_id")
    private String reference;

    @CqlName("txn_reverse_flag")
    private String reverseFlag;

    @CqlName("txn_reverse_id")
    private String reverseTxnId;

    @CqlName("original_ccy")
    private String originalCurrency;

    @CqlName("o_txn_exchange_rate")
    private BigDecimal originalExchangeRate;

    @CqlName("original_Amount")
    private BigDecimal originalAmount;

    @CqlName("exchange_rate")
    private BigDecimal exchangeRate;

    @CqlName("ordering_benef_party_id")
    private String counterpartyCif;

    @CqlName("tpp_name")
    private String tppName;

    @CqlName("tpp_application_name")
    private String tppApplicationName;

    @CqlName("txn_order_number")
    private String orderNumber;

    @CqlName("teller_code")
    private String tellerCode;

    @CqlName("rejection_code_message")
    private String reversePaymentRejectMessage;

    //    @CqlName("txn_write_id")
//    private String asrId;

    //    @CqlName("cash_txn_indicator")
//    private String cashIndicator;

    //    @CqlName("txn_host_code")
//    private int hostCode;

//    @CqlName("txn_internal_code")
//    private long internalCode;


//    @CqlName("client_national_id")
//    private String clientNationalId;

    //    @CqlName("asr_txn_type")
//    private String asrTxnType;

//    @CqlName("q_txn_type")
//    private String qTxnType;

//    @CqlName("cbs_teller")
//    private int cbsTeller;

//    @CqlName("cbs_app_code")
//    private byte cbsAppCode;

//    @CqlName("counterpart_acct_no")
//    private long counterpartAcctNo;

//    @CqlName("related_ref_id")
//    private String relatedRefId;

//    @CqlName("benef_identif_code")
//    private String benef_identif_code;

//    @CqlName("benef_ref_party_name")
//    private String benefRefPartyName;

//    @CqlName("ordering_identif_code")
//    private String orderingIdentifCode;

//    @CqlName("ordering_ref_party_name")
//    private String orderingRefPartyName;

//    @CqlName("txn_ordering_date")
//    private int txnOrderingDate;

//    @CqlName("end_to_end_id")
//    private String endToEndId;

//    @CqlName("txn_source")
//    private String txnSource;

}
