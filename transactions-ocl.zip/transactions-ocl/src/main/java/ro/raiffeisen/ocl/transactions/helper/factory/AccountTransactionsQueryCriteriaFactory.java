package ro.raiffeisen.ocl.transactions.helper.factory;

import ro.raiffeisen.ocl.transactions.helper.utils.DateUtils;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryCriteria;
import ro.raiffeisen.ocl.transactions.model.spec.rq.Cursor;
import ro.raiffeisen.ocl.transactions.model.spec.rq.TransactionsSearchRq;

import java.time.LocalDate;

public class AccountTransactionsQueryCriteriaFactory {

    public static final int DEFAULT_MAX_ROWS = 50;

    public static AccountTransactionsQueryCriteria of(final TransactionsSearchRq request,
                                                      final LocalDate firstAccountTransactionDate) {

        LocalDate from = request.getFrom();
        LocalDate to = request.getTo();
        if (from == null || to == null) {
            from = DateUtils.currentDate();
            to = firstAccountTransactionDate;
        } else {
            to = DateUtils.max(firstAccountTransactionDate, request.getTo());
        }

        //TODO handle case when from and to are lower than lastTransactionDate

        Cursor cursor = request.getCursor();
        if (cursor == null) {
            cursor = Cursor.of(from);
        }
        return new AccountTransactionsQueryCriteria(
                request.getShortAccountNr(),
                from,
                to,
                cursor,
                request.getMaxRows() == null ? DEFAULT_MAX_ROWS : request.getMaxRows(),
                request.getMinAmount(),
                request.getMaxAmount(),
                request.getQuery());
    }

}
