package ro.raiffeisen.ocl.transactions.domain.repository.dao;

import com.datastax.oss.driver.api.core.PagingIterable;
import com.datastax.oss.driver.api.core.cql.BoundStatementBuilder;
import com.datastax.oss.driver.api.mapper.annotations.Dao;
import com.datastax.oss.driver.api.mapper.annotations.Query;
import ro.raiffeisen.ocl.transactions.domain.entity.AccountTransaction;

import java.time.Instant;
import java.util.Optional;
import java.util.function.Function;

@Dao
public interface AccountTransactionDao {

    @Query("SELECT * FROM ${tableId} where account_no=:accountNo AND posting_month=:postingMonth")
    PagingIterable<AccountTransaction> findByAccountNoAndMonth(
            final long accountNo,
            final int postingMonth,
            final Function<BoundStatementBuilder, BoundStatementBuilder> setAttributes);

    @Query("SELECT * FROM ${tableId} where account_no=:accountNo AND posting_month=:postingMonth AND solr_query=:solrQuery")
    PagingIterable<AccountTransaction> findByAccountNoAndMonthAndSolrQuery(
            final long accountNo,
            final int postingMonth,
            final String solrQuery,
            final Function<BoundStatementBuilder, BoundStatementBuilder> setAttributes);

    @Query("SELECT * FROM ${tableId} where account_no=:accountNo AND posting_month=:postingMonth AND txn_timestamp=:txnTimestamp AND txn_unique_id=:id")
    Optional<AccountTransaction> findByPk(final long accountNo,
                                          final int postingMonth,
                                          final Instant txnTimestamp,
                                          final String id);

}
