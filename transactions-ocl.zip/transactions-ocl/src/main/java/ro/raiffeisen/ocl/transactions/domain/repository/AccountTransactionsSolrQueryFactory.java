package ro.raiffeisen.ocl.transactions.domain.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import ro.raiffeisen.ocl.transactions.model.AccountTransactionsQueryCriteria;

import java.math.BigDecimal;

@Slf4j
public class AccountTransactionsSolrQueryFactory {

    private static final String SOLR_WILDCARD = "*";

    public static String from(final AccountTransactionsQueryCriteria criteria) {

        final StringBuilder solrQueryBuilder = new StringBuilder();
        final BigDecimal minAmount = criteria.getMinAmount();
        final BigDecimal maxAmount = criteria.getMaxAmount();
        if (minAmount != null && maxAmount != null) {
            amountIntervalQuery(solrQueryBuilder, minAmount.toPlainString(), maxAmount.toPlainString());
        } else if (minAmount != null) {
            amountIntervalQuery(solrQueryBuilder, minAmount.toPlainString(), SOLR_WILDCARD);
        } else if (maxAmount != null) {
            amountIntervalQuery(solrQueryBuilder, BigDecimal.ZERO.toPlainString(), maxAmount.toPlainString());
        }

        final String query = criteria.getQuery();
        if (!StringUtils.isEmpty(query)) {
            final String queryContained = queryContained(criteria.getQuery());
            if (query.matches("\\d+")) {
                LOGGER.trace("only numbers query");
                final BigDecimal searchTransformed = new BigDecimal(query);
                amountIntervalQuery(solrQueryBuilder, searchTransformed.subtract(BigDecimal.ONE).toPlainString(),
                        searchTransformed.add(BigDecimal.ONE).toPlainString());
                fieldIs(solrQueryBuilder, "client_iban", queryContained);
                txDescriptionIs(solrQueryBuilder, queryContained);
            } else if (query.matches("\\d+[,.]{1}\\d+")) {
                LOGGER.trace("number with comma or dot query");
                final BigDecimal searchTransformed = new BigDecimal(query.replace(",", "."));
                amountIntervalQuery(solrQueryBuilder, searchTransformed.subtract(BigDecimal.ONE).toPlainString(),
                        searchTransformed.add(BigDecimal.ONE).toPlainString());
                fieldIs(solrQueryBuilder, "txn_desc_1", queryContained);
                fieldIs(solrQueryBuilder, "txn_desc_2", queryContained);
            } else {
                LOGGER.trace("generic query");
                fieldIs(solrQueryBuilder, "client_name", queryContained);
                fieldIs(solrQueryBuilder, "client_iban", queryContained);
                txDescriptionIs(solrQueryBuilder, queryContained);
            }
        }

        final String solrQuery = solrQueryBuilder.toString();
        return solrQuery.isEmpty() ? null : toJsonSolrQuery(solrQuery);
    }

    private static String queryContained(final String query) {

        return SOLR_WILDCARD + query + SOLR_WILDCARD;
    }

    private static void txDescriptionIs(final StringBuilder solrQueryBuilder, final String value) {
        fieldIs(solrQueryBuilder, "txn_desc", value);
    }

    private static void fieldIs(final StringBuilder solrQueryBuilder, final String field, final String value) {
        solrQueryBuilder.append(field).append(":").append(value).append(" ");
    }

    private static void amountIntervalQuery(final StringBuilder solrQueryBuilder, final String min, final String max) {
        fieldInInterval(solrQueryBuilder, "amount_double", min, max);
        fieldInInterval(solrQueryBuilder, "amount_local_ccy_double", min, max);
    }

    private static void fieldInInterval(final StringBuilder solrQueryBuilder,
                                        final String fieldName,
                                        final String min,
                                        final String max) {

        solrQueryBuilder.append(fieldName).append(":[").append(min).append(" TO ").append(max).append("] ");
    }

    private static String toJsonSolrQuery(final String solrQuery) {

        return "{\"q\":\"" + solrQuery + "\", \"paging\":\"driver\"}";
    }

}
