package ro.raiffeisen.ocl.transactions.config;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.internal.core.config.typesafe.DefaultDriverConfigLoader;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import ro.raiffeisen.ocl.transactions.domain.repository.dao.TransactionDaoMapper;
import ro.raiffeisen.ocl.transactions.domain.repository.dao.TransactionDaoMapperBuilder;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Configuration
public class CassandraConfiguration {

    private static final Pattern TYPE_SAFE_LIST_PATTERN = Pattern.compile("(.+)\\[(\\d+)]");
    private static final String DRIVER_CONFIG_PREFIX = "datastax-java-driver";
    private final ConfigurableEnvironment env;

    @Autowired
    public CassandraConfiguration(final ConfigurableEnvironment env) {
        this.env = env;
    }

    @Bean
    public CqlSession cqlSession() {
        return CqlSession.builder().withConfigLoader(new DefaultDriverConfigLoader(this::createTypeSafeConfig) {
            public boolean supportsReloading() {
                return false;
            }
        }).build();
    }

    private Config createTypeSafeConfig() {
        Map<String, String> properties = this.driverSpringProperties();
        ConfigFactory.invalidateCaches();
        Config config = ConfigFactory.defaultOverrides()
                .withFallback(ConfigFactory.parseMap(properties, "Spring properties"))
                .withFallback(ConfigFactory.parseResources("application.conf"))
                .withFallback(ConfigFactory.parseResources("application.json"))
                .withFallback(ConfigFactory.defaultReference()).resolve();
        return config.getConfig(DRIVER_CONFIG_PREFIX);
    }

    private Map<String, String> driverSpringProperties() {
        return env.getPropertySources().stream()
                .filter(EnumerablePropertySource.class::isInstance)
                .map(EnumerablePropertySource.class::cast)
                .flatMap(propertySource -> Arrays.stream(propertySource.getPropertyNames()))
                .filter((key) -> key.startsWith(DRIVER_CONFIG_PREFIX))
                .distinct()
                .map(key -> new SimpleEntry<>(convertSpringToTypeSafe(key), env.getProperty(key)))
                .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue));
    }

    private static String convertSpringToTypeSafe(String key) {
        Matcher matcher = TYPE_SAFE_LIST_PATTERN.matcher(key);
        if (matcher.matches()) {
            key = String.format("%s.%s", matcher.group(1), matcher.group(2));
        }
        return key;
    }

    @Bean
    public TransactionDaoMapper accountTransactionDao(final CqlSession cqlSession) {
        return new TransactionDaoMapperBuilder(cqlSession).build();
    }

}